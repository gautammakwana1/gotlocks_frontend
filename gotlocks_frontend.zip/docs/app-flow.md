# App Flow

Landing Page → Account Creation → Intro Text → Home → Group Card (5 tabs)
Within Group Card:
1. Leaderboard
2. Make Your Pick
3. Current Slip
4. Chat
5. Feed / Notifications
6. Group Settings (Commissioner only)
