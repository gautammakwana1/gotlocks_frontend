import { call, put, takeLatest } from "redux-saga/effects";
import axios, { AxiosResponse } from "axios";
import { API_BASE_URL } from "@/lib/utils/api";
import axiosInstance from "@/lib/utils/axiosInstance";
import type { SagaIterator } from "redux-saga";
import { fetchMyProgressFailure, fetchMyProgressRequest, fetchMyProgressSuccess, fetchMyTutorialProgressFailure, fetchMyTutorialProgressRequest, fetchMyTutorialProgressSuccess, fetchProgressByUserIdFailure, fetchProgressByUserIdRequest, fetchProgressByUserIdSuccess, redeemGlobalPointsFailure, redeemGlobalPointsRequest, redeemGlobalPointsSuccess, updateTutorialProgressFailure, updateTutorialProgressRequest, updateTutorialProgressSuccess } from "../slices/progressSlice";
import { PayloadAction } from "@reduxjs/toolkit";
import { FetchProgressByUserIdPayload, RedeemGlobalPointsPayload, TutorialProgress, UpdateTutorialProgressPayload } from "@/lib/interfaces/interfaces";
type ApiErrorResponse = {
    message?: string;
};

const getErrorMessage = (error: unknown, fallback: string): string => {
    if (axios.isAxiosError<ApiErrorResponse>(error)) {
        return error.response?.data?.message ?? fallback;
    }
    if (error instanceof Error) {
        return error.message || fallback;
    }
    return fallback;
};

function* handleFetchMyProgress(): SagaIterator {
    try {
        const response: AxiosResponse<unknown> = yield call(
            axiosInstance.get,
            `${API_BASE_URL}/progress/get-my-progress`,
        );
        const payload = response.data as { data?: unknown };
        yield put(fetchMyProgressSuccess(payload.data));
    } catch (error: unknown) {
        yield put(fetchMyProgressFailure(getErrorMessage(error, "Progress Fetch Failed")));
    }
};

function* handleFetchProgressByUserId(action: PayloadAction<FetchProgressByUserIdPayload>): SagaIterator {
    try {
        const { user_id } = action.payload;

        const response: AxiosResponse<unknown> = yield call(
            axiosInstance.get,
            `${API_BASE_URL}/progress/progress-by-user-id`,
            {
                params: { user_id }
            }
        );
        const payload = response.data as { data?: unknown };
        yield put(fetchProgressByUserIdSuccess(payload.data));
    } catch (error: unknown) {
        yield put(fetchProgressByUserIdFailure(getErrorMessage(error, "Progress Fetch Failed")));
    }
};

function* handleRedeemGlobalPoints(action: PayloadAction<RedeemGlobalPointsPayload>): SagaIterator {
    try {
        const response: AxiosResponse<unknown> = yield call(
            axiosInstance.put,
            `${API_BASE_URL}/progress/redeem-points`,
            action.payload
        );
        const payload = response.data as { data?: unknown };
        yield put(redeemGlobalPointsSuccess(payload));
    } catch (error: unknown) {
        yield put(redeemGlobalPointsFailure(getErrorMessage(error, "Redemption points failed")));
    }
};

function* handleFetchMyTutorialProgress(): SagaIterator {
    try {
        const response: AxiosResponse<unknown> = yield call(
            axiosInstance.get,
            `${API_BASE_URL}/progress/tutorial-progress`,
        );
        const payload = response.data as { data?: { progress: TutorialProgress } };
        const welcomIntro = payload.data?.progress.hasSeenWelcomeIntro;
        const groupIntro = payload.data?.progress.hasSeenGroupIntro;
        const socialIntro = payload.data?.progress.hasSeenSocialIntro;
        yield put(fetchMyTutorialProgressSuccess({ hasSeenGroupIntro: groupIntro, hasSeenWelcomeIntro: welcomIntro, hasSeenSocialIntro: socialIntro }));
    } catch (error: unknown) {
        yield put(fetchMyTutorialProgressFailure(getErrorMessage(error, "Tutorial Progress Fetch Failed")));
    }
};

function* handleUpdateTutorialProgress(action: PayloadAction<UpdateTutorialProgressPayload>): SagaIterator {
    try {
        const response: AxiosResponse<unknown> = yield call(
            axiosInstance.patch,
            `${API_BASE_URL}/progress/tutorial-update`,
            action.payload
        );
        const payload = response.data as { data?: { progress: TutorialProgress } };
        const welcomIntro = payload.data?.progress.hasSeenWelcomeIntro;
        const groupIntro = payload.data?.progress.hasSeenGroupIntro;
        const socialIntro = payload.data?.progress.hasSeenSocialIntro;
        yield put(updateTutorialProgressSuccess({ hasSeenGroupIntro: groupIntro, hasSeenWelcomeIntro: welcomIntro, hasSeenSocialIntro: socialIntro }));
    } catch (error: unknown) {
        yield put(updateTutorialProgressFailure(getErrorMessage(error, "Update Tutorial Progress Failed")));
    }
};

export default function* progressSaga() {
    yield takeLatest(fetchMyProgressRequest.type, handleFetchMyProgress);
    yield takeLatest(fetchProgressByUserIdRequest.type, handleFetchProgressByUserId);
    yield takeLatest(redeemGlobalPointsRequest.type, handleRedeemGlobalPoints);
    yield takeLatest(fetchMyTutorialProgressRequest.type, handleFetchMyTutorialProgress);
    yield takeLatest(updateTutorialProgressRequest.type, handleUpdateTutorialProgress);
};