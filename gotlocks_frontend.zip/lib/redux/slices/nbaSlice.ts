import { FetchNBAOddsPayload, FetchNBASchedulePayload, NBAState, ValidateMyNBAPickPayload } from "@/lib/interfaces/interfaces";
import { createSlice, PayloadAction } from "@reduxjs/toolkit";

const initialState: NBAState = {
    loading: false,
    error: null,
    message: null,
    nbaSchedulesWithOdds: null,
    nbaSchedules: null,
    fanduelNbaOdds: null,
    draftkingNbaOdds: null,
    oddsLoading: false,
    validateLoading: false,
    validatePickError: null,
    validatePickMessage: null,
};

const nbaSlice = createSlice({
    name: "nba",
    initialState,
    reducers: {
        fetchNBAScheduleRequest: (state, action: PayloadAction<FetchNBASchedulePayload | undefined>) => {
            void action;
            state.loading = true;
            state.error = null;
        },
        fetchNBAScheduleSuccess: (state, action) => {
            state.loading = false;
            state.nbaSchedulesWithOdds = action.payload.schedule;
        },
        fetchNBAScheduleFailure: (state, action) => {
            state.loading = false;
            state.error = action.payload;
        },
        cleatFetchNBAScheduleMessage: (state) => {
            state.error = null;
            state.message = null;
        },

        fetchNBAScheduleByTimezoneRequest: (state, action: PayloadAction<FetchNBASchedulePayload | undefined>) => {
            void action;
            state.loading = true;
            state.error = null;
        },
        fetchNBAScheduleByTimezoneSuccess: (state, action) => {
            state.loading = false;
            state.nbaSchedules = action.payload.schedule;
        },
        fetchNBAScheduleByTimezoneFailure: (state, action) => {
            state.loading = false;
            state.error = action.payload;
        },
        cleatFetchNBAScheduleByTimezoneMessage: (state) => {
            state.error = null;
            state.message = null;
        },

        fetchFanduelNBAOddsRequest: (state, action: PayloadAction<FetchNBAOddsPayload & { silent?: boolean } | undefined>) => {
            void action;
            if (!action.payload?.silent) {
                state.oddsLoading = true;
            }
            state.error = null;
        },
        fetchFanduelNBAOddsSuccess: (state, action) => {
            state.oddsLoading = false;
            state.fanduelNbaOdds = action.payload.odds;
        },
        fetchFanduelNBAOddsFailure: (state, action) => {
            state.oddsLoading = false;
            state.error = action.payload;
        },
        cleatFetchFanduelNBAOddsMessage: (state) => {
            state.error = null;
            state.message = null;
        },

        fetchDraftkingsNBAOddsRequest: (state, action: PayloadAction<FetchNBAOddsPayload & { silent?: boolean } | undefined>) => {
            void action;
            if (!action.payload?.silent) {
                state.oddsLoading = true;
            }
            state.error = null;
        },
        fetchDraftkingsNBAOddsSuccess: (state, action) => {
            state.oddsLoading = false;
            state.draftkingNbaOdds = action.payload.odds;
        },
        fetchDraftkingsNBAOddsFailure: (state, action) => {
            state.oddsLoading = false;
            state.error = action.payload;
        },
        cleatFetchDraftkingsNBAOddsMessage: (state) => {
            state.error = null;
            state.message = null;
        },

        nbaPickValidateRequest: (state, action: PayloadAction<ValidateMyNBAPickPayload | undefined>) => {
            void action;
            state.validateLoading = true;
            state.validatePickError = null;
        },
        nbaPickValidateSuccess: (state, action) => {
            state.validateLoading = false;
            state.validatePickMessage = action.payload.message;
        },
        nbaPickValidateFailure: (state, action) => {
            state.validateLoading = false;
            state.validatePickError = action.payload;
        },
        cleatNbaPickValidateMessage: (state) => {
            state.validatePickError = null;
            state.validatePickMessage = null;
        },
    },
});

export const {
    fetchNBAScheduleRequest,
    fetchNBAScheduleSuccess,
    fetchNBAScheduleFailure,
    cleatFetchNBAScheduleMessage,
    fetchFanduelNBAOddsRequest,
    fetchFanduelNBAOddsSuccess,
    fetchFanduelNBAOddsFailure,
    cleatFetchFanduelNBAOddsMessage,
    fetchDraftkingsNBAOddsRequest,
    fetchDraftkingsNBAOddsSuccess,
    fetchDraftkingsNBAOddsFailure,
    cleatFetchDraftkingsNBAOddsMessage,
    nbaPickValidateRequest,
    nbaPickValidateSuccess,
    nbaPickValidateFailure,
    cleatNbaPickValidateMessage,
    fetchNBAScheduleByTimezoneRequest,
    fetchNBAScheduleByTimezoneSuccess,
    fetchNBAScheduleByTimezoneFailure,
    cleatFetchNBAScheduleByTimezoneMessage,
} = nbaSlice.actions;

export default nbaSlice.reducer;