export const greenGradientBox =
    "relative overflow-hidden rounded-3xl border border-white/10 bg-gradient-to-br from-emerald-400/20 via-emerald-500/10 to-white/5 shadow-lg shadow-emerald-500/20";
