export const displayNameGradientStyle = {
    backgroundImage:
        "linear-gradient(130deg, #ffffff 0%, #f2f4f8 35%, #dfe7f0 75%, #cfd9e7 100%)",
    textShadow: "0 1px 3px rgba(0,0,0,0.55), 0 0 12px rgba(0,0,0,0.28)",
    letterSpacing: "0.06em",
} as const;
