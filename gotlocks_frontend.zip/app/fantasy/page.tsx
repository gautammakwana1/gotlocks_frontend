"use client";

import GroupsTab from "@/components/profile/GroupsTab";

const FantasyPage = () => <GroupsTab />;

export default FantasyPage;
