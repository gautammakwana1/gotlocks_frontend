"use client";

import { redirect } from "next/navigation";

const IntroTextPage = () => {
  redirect("/home");
};

export default IntroTextPage;
