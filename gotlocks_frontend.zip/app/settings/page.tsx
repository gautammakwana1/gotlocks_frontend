import { redirect } from "next/navigation";

const SettingsRedirect = () => {
  redirect("/profile");
};

export default SettingsRedirect;
