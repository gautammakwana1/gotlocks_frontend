"use client";

import {
    ReactNode,
    useCallback,
    useEffect,
    useId,
    useMemo,
    useRef,
    useState,
    type ChangeEvent,
    type MouseEvent as ReactMouseEvent,
} from "react";
import Image from "next/image";
import { Profile, RootState } from "@/lib/interfaces/interfaces";
import { useDispatch, useSelector } from "react-redux";
import { updateProfileRequest } from "@/lib/redux/slices/authSlice";
import { checkAnyRestrictedWords, checkForReservedWords, generateProfileImageUrl } from "@/lib/utils/helpers";
import { UserIcon } from "../layout/MainTabBar";
import { StartIcon } from "../ui/SvgIcons";

interface FormErrors {
    username?: string;
}

type ProfileHeaderStats = {
    posts: number;
    wins: number;
    combos: number;
    followers: number;
    following: number;
    groups: number;
    joinedAt?: string;
};

type ProfileHeaderProgress = {
    level: number;
    lifetimeXp: number;
    xpToday: number;
    xpIntoLevel: number;
    xpToNext: number;
    xpRemaining: number;
    levelProgressPercent: number;
};

type ProfileHeaderRecord = {
    wins: number;
    losses: number;
    pending: number;
};

type ProfileHeaderProps = {
    user: Profile;
    mode: "self" | "public";
    profileVisible: boolean | undefined;
    showLockedPrivateSummary?: boolean;
    isSelf: boolean;
    showFollowControls: boolean;
    targetBlockedViewer: boolean;
    viewerBlockedTarget: boolean;
    isFollowing: boolean;
    isFollowRequested?: boolean;
    record: ProfileHeaderRecord;
    stats: ProfileHeaderStats;
    progress: ProfileHeaderProgress;
    onShowScoringRules: () => void;
    onFollowToggle: () => void;
    onAvatarChange: (event: ChangeEvent<HTMLInputElement>) => void;
    onRemoveAvatar: () => void;
    onPrivacyToggle: () => void;
    onFollowersClick?: () => void;
    onFollowingClick?: () => void;
};

const BADGE_PLACEHOLDERS = Array.from({ length: 3 }, (_, index) => `Locked badge ${index + 1}`);
const numberFormatter = new Intl.NumberFormat("en-US");

const buildInitials = (handle: string) => {
    const segments = handle.split(/[^a-zA-Z0-9]+/).filter(Boolean);
    const source = segments.length ? segments : [handle];
    const initials = source
        .map((segment) => segment.charAt(0))
        .join("")
        .slice(0, 2)
        .toUpperCase();
    return initials || "GL";
};

type ProfileAvatarProps = {
    avatarUrl?: string | null;
    displayName: string;
    initials: string;
    setIsAvatarOpen?: (isOpen: boolean) => void;
};

const ProfileAvatar = ({ avatarUrl, displayName, setIsAvatarOpen }: ProfileAvatarProps) => (
    <div className="relative -ml-1 flex h-18 w-18 items-center justify-center sm:h-22 sm:w-22">
        <div className="absolute inset-0 rounded-full bg-gradient-to-br from-sky-200/60 via-sky-500/20 to-white/10" />
        <div className="absolute inset-[6px] rounded-full border border-sky-200/40 bg-black/40" />
        <div
            className="relative z-10 flex h-14 w-14 items-center justify-center overflow-hidden rounded-full border border-sky-300/40 bg-sky-500/20 text-white sm:h-18 sm:w-18"
            onClick={setIsAvatarOpen ? () => setIsAvatarOpen(true) : undefined}
        >
            {avatarUrl ? (
                <Image
                    src={avatarUrl}
                    alt={`${displayName} avatar`}
                    className="h-full w-full object-cover"
                    width={56}
                    height={56}
                    draggable={false}
                    onDragStart={(e) => e.preventDefault()}
                    unoptimized
                />
            ) : (
                <UserIcon className="h-8 w-8 text-white/80 sm:h-10 sm:w-10" />
            )}
        </div>
    </div>
);

type FollowerStatsProps = {
    followers: number;
    following: number;
    className?: string;
    showStats: boolean;
    onFollowersClick?: () => void;
    onFollowingClick?: () => void;
};

const FollowerStats = ({
    followers,
    following,
    className = "",
    onFollowersClick,
    onFollowingClick,
    showStats = true,
}: FollowerStatsProps) => (
    <div
        className={`flex flex-nowrap items-center gap-2 text-[10px] uppercase tracking-[0.14em] text-sky-100/80 ${className}`}
    >
        {onFollowersClick ? (
            <button
                type="button"
                onClick={onFollowersClick}
                className="whitespace-nowrap transition hover:text-white"
                disabled={!showStats}
            >
                {followers} followers
            </button>
        ) : (
            <span className="whitespace-nowrap">{followers} followers</span>
        )}
        <span aria-hidden className="h-3 w-px bg-white/25" />
        {onFollowingClick ? (
            <button
                type="button"
                onClick={onFollowingClick}
                className="whitespace-nowrap transition hover:text-white"
                disabled={!showStats}
            >
                {following} following
            </button>
        ) : (
            <span className="whitespace-nowrap">{following} following</span>
        )}
    </div>
);

const ProfileHeader = ({
    user,
    mode,
    profileVisible = false,
    showLockedPrivateSummary = false,
    isSelf,
    showFollowControls,
    viewerBlockedTarget,
    isFollowing,
    isFollowRequested = false,
    record,
    stats,
    progress,
    onShowScoringRules,
    onFollowToggle,
    onAvatarChange,
    onRemoveAvatar,
    onFollowersClick,
    onFollowingClick,
}: ProfileHeaderProps) => {
    const dispatch = useDispatch();
    const avatarInputId = useId();
    const [isEditing, setIsEditing] = useState(false);
    const [username, setUsername] = useState(user?.username || "");
    const [errors, setErrors] = useState<FormErrors>({});
    const [isAvatarOpen, setIsAvatarOpen] = useState(false);
    const avatarMenuRef = useRef<HTMLDetailsElement | null>(null);
    const optionsMenuRef = useRef<HTMLDetailsElement | null>(null);
    const displayName = user.username ?? user.full_name ?? "Member";
    const initials = useMemo(() => buildInitials(displayName), [displayName]);
    const avatarUrl = generateProfileImageUrl(user.profile_image);
    const showStats = mode === "self" || profileVisible;
    const showRightSummary = showStats || showLockedPrivateSummary;
    const showNumericProgress = mode === "self";
    const showFollowSection = mode === "public" && showFollowControls && !isSelf && !viewerBlockedTarget;
    const showFollowerStats = showStats || showFollowSection;
    const privacyStatusLabel = user.is_public ? "public profile" : "private profile";
    const formattedLifetimeXp = numberFormatter.format(progress.lifetimeXp);
    const recordItems = [
        { label: "W", value: record?.wins ?? 0, tone: "text-emerald-100" },
        { label: "L", value: record?.losses ?? 0, tone: "text-red-100" },
        { label: "P", value: record?.pending ?? 0, tone: "text-blue-100" },
    ];

    const { loading } = useSelector((state: RootState) => state.user);

    const closeDetailsMenu = (event: ReactMouseEvent<HTMLElement>) => {
        const details = event.currentTarget.closest("details");
        if (details instanceof HTMLDetailsElement) {
            details.open = false;
        }
    };

    // const renderOptionsMenu = () => {
    //     return (
    //         <details ref={optionsMenuRef} className="relative z-20">
    //             <summary
    //                 aria-label="Profile options"
    //                 className="flex h-7 w-7 cursor-pointer items-center justify-center rounded-full border border-white/20 bg-white/10 text-white/80 transition hover:border-sky-300/60 hover:text-sky-100 sm:h-8 sm:w-8 [&::-webkit-details-marker]:hidden"
    //             >
    //                 <EditIcon />
    //             </summary>
    //             <div className="absolute right-0 top-full mt-2 w-48 rounded-2xl border border-white/10 bg-black/80 p-2 text-xs uppercase tracking-[0.16em] text-white shadow-lg backdrop-blur">
    //                 <button
    //                     type="button"
    //                     onClick={(event) => {
    //                         handleEdit();
    //                         closeDetailsMenu(event);
    //                     }}
    //                     className="flex w-full items-center justify-between rounded-xl px-3 py-2 text-left transition hover:bg-white/10"
    //                 >
    //                     edit name
    //                 </button>
    //                 <button
    //                     type="button"
    //                     onClick={(event) => {
    //                         onPrivacyToggle();
    //                         closeDetailsMenu(event);
    //                     }}
    //                     className={`mt-1 flex w-full items-center justify-between rounded-xl border px-3 py-2 text-[11px] uppercase tracking-wide transition ${user.is_public
    //                         ? "border-sky-300/60 bg-sky-500/15 text-sky-100"
    //                         : "border-white/20 bg-white/10 text-white"
    //                         }`}
    //                 >
    //                     {user.is_public ? "Public profile" : "Private profile"}
    //                     <span className="text-[10px] text-white/60">
    //                         {user.is_public ? "visible" : "hidden"}
    //                     </span>
    //                 </button>
    //             </div>
    //         </details>
    //     );
    // };

    useEffect(() => {
        if (!user?.username) return;

        setUsername(user?.username);
    }, [user?.username]);

    useEffect(() => {
        const handleClick = (event: globalThis.MouseEvent) => {
            const menus = [avatarMenuRef.current, optionsMenuRef.current].filter(
                Boolean
            ) as HTMLDetailsElement[];

            if (!menus.length) return;

            const openMenus = menus.filter((menu) => menu.open);
            if (!openMenus.length) return;

            const target = event.target instanceof Node ? event.target : null;

            if (target && openMenus.some((menu) => menu.contains(target))) {
                return;
            }

            if (openMenus.some((menu) => menu.contains(target))) {
                return;
            }

            openMenus.forEach((menu) => {
                menu.open = false;
            });
        };

        const handleEscape = (event: KeyboardEvent) => {
            if (event.key !== "Escape") return;
            const menus = [avatarMenuRef.current, optionsMenuRef.current].filter(
                Boolean
            ) as HTMLDetailsElement[];
            const openMenus = menus.filter((menu) => menu.open);
            if (!openMenus.length) return;
            openMenus.forEach((menu) => {
                menu.open = false;
            });
        };

        document.addEventListener("mousedown", handleClick);
        document.addEventListener("keydown", handleEscape);
        return () => {
            document.removeEventListener("mousedown", handleClick);
            document.removeEventListener("keydown", handleEscape);
        };
    }, []);

    const validate = useCallback((): boolean => {
        const nextErrors: FormErrors = {};

        if (!username?.trim()) {
            nextErrors.username = "Username is required.";
        }

        const containsNameRestricted = checkAnyRestrictedWords(username);
        if (containsNameRestricted) {
            nextErrors.username = "Username contains inappropriate language.";
        }

        const containsReserveWords = checkForReservedWords(username);
        if (containsReserveWords) {
            nextErrors.username = "Username contains reserved words.";
        }

        setErrors(nextErrors);
        return Object.keys(nextErrors).length === 0;
    }, [username]);

    const handleSave = (event: React.FormEvent) => {
        event.preventDefault();
        if (!validate()) return;
        const cleanUsername = username.trim();

        const formData = new FormData();
        formData.append("username", cleanUsername);

        if (cleanUsername === user?.username) {
            setIsEditing(false);
            return;
        }

        dispatch(updateProfileRequest(formData));

        setIsEditing(false);
    };

    const handleCancel = () => {
        setIsEditing(false);
        setUsername(user?.username || "");
        setErrors({});
    };

    const renderFollowControls = (className = "") => {
        if (!showFollowSection) return null;
        return (
            <div className={`flex flex-wrap items-center gap-2 ${className}`}>
                {isFollowing ? (
                    <details className="relative">
                        <summary
                            aria-label="Following options"
                            className="list-none cursor-pointer rounded-lg border border-sky-300/60 bg-sky-500/15 px-2.5 py-1 text-[10px] tracking-[0.14em] text-sky-100 transition hover:border-sky-200/80 [&::-webkit-details-marker]:hidden"
                        >
                            following
                        </summary>
                        <div className="absolute left-0 top-full mt-2 w-20 rounded-lg border border-white/10 bg-black/80 p-1 text-[10px] tracking-[0.14em] text-white shadow-lg backdrop-blur">
                            <button
                                type="button"
                                onClick={(event) => {
                                    onFollowToggle();
                                    closeDetailsMenu(event);
                                }}
                                className="flex w-full items-center justify-start rounded-md px-1.5 py-1 text-left text-red-200 transition hover:bg-white/10"
                            >
                                unfollow
                            </button>
                        </div>
                    </details>
                ) : isFollowRequested ? (
                    <button
                        type="button"
                        disabled
                        className="cursor-default rounded-lg border border-amber-300/45 bg-amber-500/10 px-2.5 py-1 text-[10px] tracking-[0.14em] text-amber-100"
                    >
                        requested
                    </button>
                ) : (
                    <button
                        type="button"
                        onClick={onFollowToggle}
                        className="rounded-lg border border-white/15 bg-white/5 px-2.5 py-1 text-[10px] tracking-[0.14em] text-white transition hover:border-sky-300/60"
                    >
                        follow
                    </button>
                )}
            </div>
        );
    };

    return (
        <header className="relative overflow-visible -mx-5 bg-black sm:-mx-6">
            <div className="relative px-5 pt-2 pb-5 sm:px-6 sm:pt-3 sm:pb-6">
                <div className="relative">
                    <div className="pointer-events-none absolute -inset-y-2 inset-x-0 rounded-[18px] bg-gradient-to-br from-slate-950/80 via-slate-900/65 to-blue-900/35 ring-1 ring-white/10 sm:-inset-y-3">
                        <div className="absolute inset-[1px] rounded-[17px] bg-gradient-to-b from-white/10 via-white/5 to-black/70" />
                        <div className="absolute inset-0 rounded-[18px] bg-[radial-gradient(circle_at_top,rgba(59,130,246,0.18),transparent_55%)]" />
                    </div>
                    <div className="relative origin-top-left scale-[0.95] pl-1 sm:scale-100 sm:pl-2">
                        <div className="relative grid gap-5 sm:gap-6 grid-cols-[minmax(0,3fr)_minmax(0,2fr)] sm:grid-cols-[minmax(0,1fr)_minmax(0,250px)] lg:grid-cols-[minmax(0,1fr)_minmax(0,280px)]">
                            <div className="relative h-full w-full p-3 sm:p-4">
                                <div className="grid grid-cols-[auto_1fr] grid-rows-[auto_auto_auto] gap-3 sm:gap-4 sm:grid-rows-[auto_1fr] sm:items-start">
                                    {mode === "self" ? (
                                        <details
                                            ref={avatarMenuRef}
                                            className="relative z-20 col-start-1 row-start-2 sm:col-start-1 sm:row-span-2 sm:row-start-1"
                                        >
                                            <summary
                                                aria-label="Profile photo actions"
                                                className="relative list-none cursor-pointer [&::-webkit-details-marker]:hidden"
                                            >
                                                <ProfileAvatar
                                                    avatarUrl={avatarUrl}
                                                    displayName={displayName}
                                                    initials={initials}
                                                />
                                                {showStats && (
                                                    <span className="sr-only">Level {progress.level}</span>
                                                )}
                                            </summary>
                                            <div className="absolute left-0 top-full mt-2 w-40 rounded-2xl border border-white/10 bg-black/80 p-2 text-xs uppercase tracking-[0.16em] text-white shadow-lg backdrop-blur">
                                                <label
                                                    htmlFor={avatarInputId}
                                                    onClick={closeDetailsMenu}
                                                    className="flex w-full cursor-pointer items-center justify-between rounded-xl px-3 py-2 transition hover:bg-white/10"
                                                >
                                                    {avatarUrl ? "edit photo" : "upload photo"}
                                                </label>
                                                {avatarUrl && (
                                                    <button
                                                        type="button"
                                                        onClick={(event) => {
                                                            onRemoveAvatar();
                                                            closeDetailsMenu(event);
                                                        }}
                                                        className="flex w-full items-center justify-between rounded-xl px-3 py-2 text-red-200 transition hover:bg-white/10"
                                                    >
                                                        remove photo
                                                    </button>
                                                )}
                                                <button
                                                    type="button"
                                                    onClick={(event) => {
                                                        setIsAvatarOpen(true);
                                                        closeDetailsMenu(event);
                                                    }}
                                                    className="flex w-full items-center justify-between rounded-xl px-3 py-2 text-red-200 transition hover:bg-white/10"
                                                >
                                                    view photo
                                                </button>
                                            </div>
                                        </details>
                                    ) : (
                                        <div className="relative col-start-1 row-start-2 sm:col-start-1 sm:row-span-2 sm:row-start-1">
                                            <ProfileAvatar
                                                avatarUrl={avatarUrl}
                                                displayName={displayName}
                                                initials={initials}
                                                setIsAvatarOpen={setIsAvatarOpen}
                                            />
                                            {showStats && (
                                                <span className="sr-only">Level {progress.level}</span>
                                            )}
                                        </div>
                                    )}
                                    <div className="min-w-0 col-span-2 row-start-1 sm:col-span-1 sm:col-start-2 sm:row-start-1">
                                        <div className="flex flex-wrap items-start justify-between gap-2">
                                            <div className="min-w-0">
                                                <div className="flex flex-wrap items-center gap-2">
                                                    <div className="truncate text-xl font-semibold leading-tight text-white sm:text-2xl">
                                                        {displayName}
                                                    </div>
                                                    {/* {mode === "self" ? renderOptionsMenu() : null} */}
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    {showFollowerStats && (
                                        <div className="min-w-0 col-start-2 row-start-2 flex flex-col gap-3 self-center sm:col-start-2 sm:row-start-2 sm:h-full sm:self-auto">
                                            {showStats && (
                                                <div className="w-full text-[11px] uppercase tracking-wide text-sky-100/75">
                                                    <div className="flex flex-wrap items-center gap-3">
                                                        <span className="shrink-0">Lvl {progress.level}</span>
                                                        <div className="h-1.5 min-w-[100px] flex-1 rounded-full bg-white/10 sm:min-w-[140px]">
                                                            <div
                                                                className="h-1.5 rounded-full bg-sky-400/80 transition-all"
                                                                style={{ width: `${progress.levelProgressPercent}%` }}
                                                            />
                                                        </div>
                                                        {showNumericProgress && (
                                                            <span className="ml-auto shrink-0 text-right text-sky-100/70">
                                                                {progress.xpRemaining} XP to next
                                                            </span>
                                                        )}
                                                    </div>
                                                    <div className="mt-1 text-right text-sky-100/70">
                                                        <span className="text-white/55">Total XP </span>
                                                        <span className="font-semibold text-white">
                                                            {formattedLifetimeXp}
                                                        </span>
                                                    </div>
                                                </div>
                                            )}
                                            <div className={`flex flex-col gap-2 ${showStats ? "mt-auto" : ""}`}>
                                                <div className="hidden sm:block">
                                                    <FollowerStats
                                                        followers={stats.followers}
                                                        following={stats.following}
                                                        className="sm:flex sm:gap-3 sm:text-[11px] sm:tracking-[0.18em] sm:mt-2"
                                                        onFollowersClick={onFollowersClick}
                                                        onFollowingClick={onFollowingClick}
                                                        showStats={showStats}
                                                    />
                                                    <p className="mt-1 text-[10px] uppercase tracking-[0.16em] text-white/55">
                                                        {privacyStatusLabel}
                                                    </p>
                                                </div>
                                                {renderFollowControls("hidden sm:flex sm:mt-2")}
                                            </div>
                                        </div>
                                    )}
                                    {showFollowerStats && (
                                        <div className="col-start-1 row-start-3 col-span-2 sm:hidden">
                                            <FollowerStats
                                                followers={stats.followers}
                                                following={stats.following}
                                                className="mt-2"
                                                onFollowersClick={onFollowersClick}
                                                onFollowingClick={onFollowingClick}
                                                showStats={showStats}
                                            />
                                            <p className="mt-1 text-[10px] uppercase tracking-[0.16em] text-white/55">
                                                {privacyStatusLabel}
                                            </p>
                                            {renderFollowControls("mt-3")}
                                        </div>
                                    )}
                                </div>
                            </div>
                            <div className={`flex h-full flex-col gap-4 ${!viewerBlockedTarget ? "border-l border-white/10" : ""} pl-4 sm:gap-5 sm:pl-5 lg:pl-6`}>
                                {showRightSummary && (
                                    <div className="space-y-3 pt-2">
                                        <div className="flex flex-nowrap items-center gap-3 text-xs uppercase tracking-[0.16em] text-white/80 sm:gap-4 sm:text-sm sm:tracking-[0.18em]">
                                            {recordItems.map((item) => (
                                                <div
                                                    key={item.label}
                                                    className="flex items-baseline gap-1.5 whitespace-nowrap sm:gap-2"
                                                >
                                                    <span className="text-[10px] font-semibold text-white/70 sm:text-[11px]">
                                                        {item.label}
                                                    </span>
                                                    <span className={`text-[11px] font-bold sm:text-base ${item.tone}`}>
                                                        {item.value}
                                                    </span>
                                                </div>
                                            ))}
                                        </div>
                                        <button
                                            type="button"
                                            onClick={onShowScoringRules}
                                            className="whitespace-nowrap px-1 py-1 text-[10px] font-semibold lowercase tracking-wide text-sky-200 underline decoration-white/30 transition hover:text-sky-100 sm:text-[11px]"
                                        >
                                            profile scoring rules
                                        </button>
                                    </div>
                                )}
                                {!viewerBlockedTarget && (
                                    <div
                                        className={`space-y-3 ${showRightSummary
                                            ? "border-t border-white/10 pt-4 pb-1 mt-auto sm:mt-0"
                                            : ""
                                            }`}
                                    >
                                        <div className="flex flex-col gap-1 sm:flex-row sm:items-center sm:justify-between sm:gap-2">
                                            <p className="text-[10px] uppercase tracking-[0.16em] text-[var(--text-muted)] sm:text-[11px] sm:tracking-[0.18em]">
                                                badges
                                            </p>
                                            <span className="text-[7px] uppercase tracking-wide text-[var(--text-secondary)] sm:text-[9px] sm:pr-3">
                                                coming soon
                                            </span>
                                        </div>
                                        <div className="mt-2 flex flex-wrap gap-2">
                                            {BADGE_PLACEHOLDERS.map((label, index) => (
                                                <div
                                                    key={`${label}-${index}`}
                                                    className="flex h-7 w-7 items-center justify-center rounded-full border border-white/10 bg-white/5 text-[var(--text-secondary)]"
                                                >
                                                    <StartIcon />
                                                    <span className="sr-only">{label}</span>
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>
                </div>
                <input
                    id={avatarInputId}
                    type="file"
                    accept="image/*"
                    onChange={onAvatarChange}
                    className="sr-only"
                />
            </div>

            {isEditing && (
                <ModalShell onClose={handleCancel} maxWidthClass="max-w-sm">
                    <form onSubmit={handleSave} className="space-y-4 text-center">
                        <div className="space-y-1">
                            <p className="text-xs uppercase tracking-[0.16em] text-gray-400">choose unique username</p>
                            <p className="text-lg font-semibold text-white">Enter Username</p>
                        </div>
                        <input
                            type="text"
                            value={username}
                            onChange={(event) => {
                                setUsername(event.target.value);
                                setErrors((prev) => ({ ...prev, username: undefined }));
                            }}
                            placeholder="username"
                            autoFocus
                            className="w-full rounded-2xl border border-white/15 bg-black/60 px-4 py-2.5 text-base sm:text-sm text-white outline-none transition focus:border-sky-400/70"
                        />
                        {errors.username && (
                            <span className="text-xs font-medium text-red-400">
                                {errors.username}
                            </span>
                        )}
                        <div className="flex justify-center gap-3">
                            <button
                                type="button"
                                onClick={handleCancel}
                                className="rounded-xl border border-white/15 px-4 py-2 text-sm font-semibold uppercase tracking-wide text-gray-200 transition hover:border-white/30 hover:text-white"
                            >
                                Cancel
                            </button>
                            <button
                                type="submit"
                                className="rounded-xl border border-sky-400/60 bg-sky-500/20 px-4 py-2 text-sm font-semibold uppercase tracking-wide text-sky-100 transition hover:border-sky-300/80 hover:text-white"
                            >
                                {loading ? "Updating.." : "Update"}
                            </button>
                        </div>
                    </form>
                </ModalShell>
            )}

            {isAvatarOpen && profileVisible && (
                <ModalShell onClose={() => setIsAvatarOpen(false)} maxWidthClass="max-w-sm">
                    <div
                        className="relative max-h-[90vh] max-w-[90vw]"
                        onClick={(e) => e.stopPropagation()}
                    >
                        {avatarUrl ? (
                            <Image
                                src={avatarUrl}
                                alt={`${displayName} avatar`}
                                className="h-full w-full object-cover"
                                width={56}
                                height={56}
                                draggable={false}
                                onDragStart={(e) => e.preventDefault()}
                                unoptimized
                            />
                        ) : (
                            <UserIcon className="h-full w-full text-white/80 sm:h-full sm:w-full" />
                        )}

                        <button
                            onClick={() => setIsAvatarOpen(false)}
                            className="absolute -right-5 -top-5 flex h-10 w-10 items-center justify-center rounded-full bg-transparent text-white shadow-lg hover:bg-white/10"
                        >
                            ✕
                        </button>
                    </div>
                </ModalShell>
            )}
        </header>
    );
};

export default ProfileHeader;

const ModalShell = ({
    children,
    onClose,
    maxWidthClass = "max-w-3xl",
}: {
    children: ReactNode;
    onClose: () => void;
    maxWidthClass?: string;
}) => (
    <div
        className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 px-4 backdrop-blur-[2px]"
        onClick={onClose}
    >
        <div
            className={`relative w-full ${maxWidthClass} max-h-[90vh] overflow-y-auto rounded-3xl border border-white/10 bg-black p-5 shadow-2xl`}
            onClick={(event) => event.stopPropagation()}
        >
            {children}
        </div>
    </div>
);