"use client";

import { Pick, PickReaction, PickResult, PickType } from "@/lib/interfaces/interfaces";
import { LOSING_POST_CARD_TONE, PENDING_POST_CARD_TONE, WINNING_POST_CARD_TONE } from "@/lib/styles/postCards";
import { formatDateTime } from "@/lib/utils/date";
import { EM_DASH, extractMatchup, extractPickLine } from "@/lib/utils/pickDescription";
import { formatTierPrimary, getTierMetaForPick } from "@/lib/utils/scoring";
import { useEffect, useRef, useState } from "react";

type PostCardProps = {
    pick: Pick;
    displayName: string;
    mode: "self" | "public";
    canDelete: boolean;
    onDelete: (pickId: string) => void;
    onReaction: (reaction: PickReaction, pickId: string) => void;
};

const resultTone = (result: PickResult) => {
    switch (result) {
        case "win":
            return "border-emerald-300/70 bg-emerald-400/15 text-emerald-100";
        case "loss":
            return "border-red-400/60 bg-red-500/15 text-red-100";
        case "void":
            return "border-yellow-300/60 bg-yellow-500/15 text-yellow-100";
        case "not_found":
            return "border-yellow-300/60 bg-yellow-500/15 text-yellow-100";
        case "pending":
            return "border-blue-300/50 bg-blue-500/10 text-blue-100";
        default:
            return "border-white/10 bg-white/5 text-[var(--text-secondary)]";
    }
};

const PICK_RESULT_ACCENTS = {
    win: {
        text: "text-emerald-200",
    },
    loss: {
        text: "text-rose-200",
    },
    void: {
        text: "text-amber-100",
    },
    not_found: {
        text: "text-amber-100",
    },
    pending: {
        text: "text-cyan-200",
    },
} as const;

const PLACEHOLDER = EM_DASH;
const META_SEPARATOR = " \u00b7 ";
const UP_TRIANGLE = "\u25B2";
const DOWN_TRIANGLE = "\u25BC";

const withAlpha = (hex: string, alphaHex: string) => {
    if (hex.startsWith("#") && hex.length === 7) {
        return `${hex}${alphaHex}`;
    }
    return hex;
};

const getHexFromGradient = (color?: string) => {
    if (!color) return undefined;
    const match = color.match(/#([0-9a-fA-F]{6})/);
    return match ? `#${match[1]}` : undefined;
};

const getTierCardStyle = (color?: string) => {
    const hex = getHexFromGradient(color);
    if (!hex) return undefined;
    return {
        backgroundImage: `linear-gradient(135deg, ${withAlpha(
            hex,
            "55"
        )}, ${withAlpha(hex, "22")}, rgba(0,0,0,0))`,
    };
};

const resolveLegCategoryLabel = (market?: string) => {
    if (!market) return null;
    const upper = market.toUpperCase();
    if (upper.includes("MONEYLINE") || upper.includes("POINT SPREAD") || upper.includes("TOTAL")) {
        return "game lines";
    }
    if (upper.includes("PASSING")) return "passing props";
    if (upper.includes("RECEIVING") || upper.includes("RECEPTION")) return "receiving props";
    if (upper.includes("RUSHING")) return "rushing props";
    if (upper.includes("TD")) return "td scorer props";
    return market.replace(/Player\s+/i, "Player ").toLowerCase();
};

const WinningHeaderArt = () => (
    <div
        aria-hidden
        className="pointer-events-none absolute inset-x-0 top-0 z-0 h-12 overflow-hidden rounded-t-[11px] opacity-[0.16] [mask-image:linear-gradient(to_bottom,black,transparent)]"
        style={{
            backgroundImage: "url('/winning-card-lock-bg.svg')",
            backgroundRepeat: "no-repeat",
            backgroundPosition: "center 18%",
            backgroundSize: "cover",
        }}
    />
);

const PostCard = ({ pick, canDelete, onDelete, onReaction }: PostCardProps) => {
    const [collapsed, setCollapsed] = useState(false);
    const [menuOpen, setMenuOpen] = useState(false);
    const menuRef = useRef<HTMLDivElement | null>(null);

    useEffect(() => {
        if (!menuOpen) return;
        const handlePointerDown = (event: PointerEvent) => {
            const target = event.target as Node | null;
            if (!target || menuRef.current?.contains(target)) return;
            setMenuOpen(false);
        };
        const handleKeyDown = (event: KeyboardEvent) => {
            if (event.key === "Escape") {
                setMenuOpen(false);
            }
        };
        document.addEventListener("pointerdown", handlePointerDown);
        document.addEventListener("keydown", handleKeyDown);
        return () => {
            document.removeEventListener("pointerdown", handlePointerDown);
            document.removeEventListener("keydown", handleKeyDown);
        };
    }, [menuOpen]);

    const tierMeta = getTierMetaForPick({
        odds: pick.odds_bracket,
        label: pick.difficulty_label,
        points: pick.points,
        mode: "global",
    });
    const tierPrimary = tierMeta
        ? `${formatTierPrimary(tierMeta.tier)}${tierMeta.points ? ` • ${tierMeta.points} XP` : ""
        }`
        : "Tier -";
    const tierCardStyle = tierMeta?.color ? getTierCardStyle(tierMeta.color) : undefined;
    const tierCardTone = tierCardStyle
        ? "bg-transparent"
        : tierMeta?.color
            ? `bg-gradient-to-br ${tierMeta.color}`
            : "bg-white/[0.04]";
    const confidenceLabel = pick.confidence ? pick.confidence.toLowerCase() : null;
    const confidenceTone =
        confidenceLabel === "high"
            ? "text-sky-100"
            : confidenceLabel === "medium"
                ? "text-amber-100"
                : confidenceLabel === "low"
                    ? "text-rose-100"
                    : "text-slate-500";
    const comboLabel = pick.is_combo
        ? `combo${pick.legs?.length ? ` · ${pick.legs.length} legs` : ""}`
        : null;
    const resultLabel = (pick.result ?? "pending") as PickResult;
    const resultDisplay = resultLabel === "not_found" ? "n/a" : resultLabel;
    // const pointsValue = resultLabel === "pending" ? null : getPickPoints(pick);
    // const pointsLabel =
    //     pointsValue === null ? "—" : `${pointsValue > 0 ? "+" : ""}${pointsValue} pts`;
    const timestamp = pick.created_at ?? pick.updated_at ?? new Date().toISOString();
    const showResultChip = pick.result && pick.result !== "pending";
    const sportLabel = pick.sport?.toString().toUpperCase() || "SPORT";
    const displayPick = pick.description ?? "No pick was submitted";
    const pickLine = extractPickLine(displayPick);
    const matchupCopy = pick?.matchup ?? extractMatchup(displayPick, pick?.matchup) ?? PLACEHOLDER;
    const gameTimeCopy = formatDateTime(pick.selection?.gameStartTime);
    const showMatchup = matchupCopy !== PLACEHOLDER;
    const showGameTime = gameTimeCopy !== PLACEHOLDER;
    const oddsCopy = pick.odds_bracket ?? PLACEHOLDER;
    const legsCount = pick.legs?.length ?? 0;
    const legsCopy = legsCount > 0 ? `${legsCount} picks` : pick.is_combo ? "combo" : null;
    const postedLine = `${legsCopy ? `${legsCopy} \u00b7 ` : ""}${formatDateTime(timestamp)}`;
    const isComboPost = Boolean(pick.is_combo || (pick.legs?.length ?? 0) > 0);
    const baseSourceTabLabel = pick.source_tab ?? (isComboPost ? "Combo" : "Pick");
    const normalizedSourceTabLabel = baseSourceTabLabel.toLowerCase();
    const singleCategoryLabel =
        normalizedSourceTabLabel === "pick"
            ? resolveLegCategoryLabel(pick.selection?.market) ?? normalizedSourceTabLabel
            : normalizedSourceTabLabel;
    const postHeaderLabel = isComboPost
        ? normalizedSourceTabLabel === "combo"
            ? "combo pick post"
            : normalizedSourceTabLabel
        : "single pick post";
    const detailCategoryLabel = isComboPost ? null : singleCategoryLabel;
    const showComboLegs = Boolean(pick.is_combo && pick.legs && pick.legs.length > 0);
    const metaLabel = [showMatchup ? matchupCopy : null, showGameTime ? gameTimeCopy : null]
        .filter(Boolean)
        .join(META_SEPARATOR);
    // const isSelfProfile = mode === "self";
    // const profilePicture = pick.profiles?.profile_image ? `${process.env.NEXT_PUBLIC_SUPABASE_S3_URL}/${pick.profiles?.profile_image}` : undefined;
    const up = pick.up ?? 0;
    const down = pick.down ?? 0;
    const userReaction = pick.reaction ?? undefined;
    const upActive = userReaction === "up";
    const downActive = userReaction === "down";
    const isWinningPost = resultLabel === "win";
    const isLosingPost = resultLabel === "loss";
    const isPendingPost = resultLabel === "pending";
    const pickAccentDotTone = isWinningPost
        ? "bg-emerald-300/80"
        : isLosingPost
            ? "bg-rose-300/80"
            : "bg-sky-300/80";
    const pickAccentTextTone = isWinningPost
        ? "text-emerald-200"
        : isLosingPost
            ? "text-rose-200"
            : "text-sky-200";
    const pickResult = pick?.result ?? "pending";
    const accent = PICK_RESULT_ACCENTS[pickResult] ?? PICK_RESULT_ACCENTS.pending;

    if (pick.pick_type !== PickType.POST) return null;

    return (
        <div className="py-4">
            <div className="flex flex-wrap items-center justify-between gap-3 px-5 pb-3 sm:px-6">
                <div className="felx items-center">
                    {collapsed && (
                        <span className={`text-[12px] font-semibold ${pickAccentTextTone}`}>
                            {postHeaderLabel}
                        </span>
                    )}
                </div>
                <div className="flex flex-wrap items-center justify-end gap-2">
                    <div className="flex items-center gap-2">
                        {collapsed && (
                            <span className="text-[12px] font-semibold text-slate-100">
                                {oddsCopy}
                            </span>
                        )}
                        <button
                            type="button"
                            onClick={() => onReaction("up", pick.id)}
                            aria-pressed={upActive}
                            className={`inline-flex items-center gap-1.5 rounded-md border px-2.5 py-1 text-[10px] font-semibold uppercase tracking-wide transition ${upActive
                                ? "border-sky-300/70 bg-sky-500/20 text-sky-100"
                                : "border-white/10 bg-white/5 text-[var(--text-secondary)] hover:border-white/30 hover:text-white"}`}
                        >
                            <span aria-hidden="true">{UP_TRIANGLE}</span>
                            <span className="tabular-nums text-[11px]">{up}</span>
                        </button>
                        <button
                            type="button"
                            onClick={() => onReaction("down", pick.id)}
                            aria-pressed={downActive}
                            className={`inline-flex items-center gap-1.5 rounded-md border px-2.5 py-1 text-[10px] font-semibold uppercase tracking-wide transition ${downActive
                                ? "border-rose-300/70 bg-rose-500/20 text-rose-100"
                                : "border-white/10 bg-white/5 text-[var(--text-secondary)] hover:border-white/30 hover:text-white"}`}
                        >
                            <span aria-hidden="true">{DOWN_TRIANGLE}</span>
                            <span className="tabular-nums text-[11px]">{down}</span>
                        </button>
                    </div>
                    {showResultChip && (
                        <span
                            className={`rounded-full px-3 py-1 text-[11px] uppercase tracking-wide ${resultTone(
                                resultLabel
                            )}`}
                        >
                            {resultDisplay}
                        </span>
                    )}
                    {canDelete && (
                        <div className="relative" ref={menuRef}>
                            <button
                                type="button"
                                onClick={() => setMenuOpen((open) => !open)}
                                aria-haspopup="menu"
                                aria-expanded={menuOpen}
                                className="inline-flex h-7 w-7 items-center justify-center rounded-md border border-white/10 text-[14px] text-[var(--text-secondary)] transition hover:border-white/30 hover:text-white"
                            >
                                {"\u22EF"}
                            </button>
                            {menuOpen && (
                                <div className="absolute right-0 z-20 mt-2 w-32 rounded-lg border border-white/10 bg-black/90 p-1 shadow-lg">
                                    <button
                                        type="button"
                                        onClick={() => {
                                            setMenuOpen(false);
                                            onDelete(pick.id);
                                        }}
                                        className="w-full rounded-md px-3 py-2 text-left text-[11px] font-semibold uppercase tracking-wide text-rose-100 transition hover:bg-rose-500/10 hover:text-rose-50"
                                    >
                                        Delete
                                    </button>
                                </div>
                            )}
                        </div>
                    )}
                    <button
                        type="button"
                        onClick={() => setCollapsed((prev) => !prev)}
                        aria-expanded={!collapsed}
                        aria-label={collapsed ? "Expand post" : "Collapse post"}
                        className={`inline-flex h-4 w-4 items-center justify-center text-[10px] font-semibold transition ${collapsed
                            ? "text-[var(--text-secondary)] hover:text-white"
                            : "text-white/90 hover:text-white"
                            }`}
                    >
                        {collapsed ? "\u25BC" : "\u25B2"}
                    </button>
                </div>
            </div>

            {!collapsed && (
                <div className="space-y-3 px-5 sm:px-6">
                    <div
                        className={`flex flex-col gap-2 sm:flex-row ${showComboLegs ? "sm:items-start" : "sm:items-stretch"
                            }`}
                    >
                        <div
                            className={`order-2 flex w-full h-full gap-2 sm:order-1 sm:w-[140px] sm:h-[140px] sm:flex-col ${showComboLegs ? "sm:self-start" : "sm:self-stretch"
                                }`}
                        >
                            <div
                                className={`w-full h-full flex-1 rounded-xl sm:max-h-[65px] border border-white/10 p-2.5 shadow-[inset_0_0_10px_rgba(15,23,42,0.2)] ${showComboLegs ? "sm:flex-none" : ""
                                    } ${tierCardTone}`}
                                style={tierCardStyle}
                            >
                                <span className="block text-[10px] font-semibold uppercase tracking-wide text-slate-400">
                                    tier
                                </span>
                                <span className="mt-1 block text-xs font-semibold text-white">
                                    {tierPrimary}
                                </span>
                            </div>
                            <div
                                className={`w-full h-full flex-1 rounded-xl sm:max-h-[65px] border border-white/10 bg-white/[0.04] p-2.5 shadow-[inset_0_0_10px_rgba(15,23,42,0.2)] ${showComboLegs ? "sm:flex-none" : ""
                                    }`}
                            >
                                <span className="block text-[10px] font-semibold uppercase tracking-wide text-slate-400">
                                    confidence
                                </span>
                                <span className={`mt-1 block text-xs font-semibold ${confidenceTone}`}>
                                    {confidenceLabel ?? "—"}
                                </span>
                            </div>
                        </div>

                        <div
                            className={`relative order-1 flex-1 overflow-hidden rounded-xl border p-3 sm:order-2 ${isWinningPost
                                ? WINNING_POST_CARD_TONE
                                : isLosingPost
                                    ? LOSING_POST_CARD_TONE
                                    : isPendingPost
                                        ? PENDING_POST_CARD_TONE
                                        : "border-white/10 bg-white/[0.04] shadow-[inset_0_0_10px_rgba(15,23,42,0.2)]"
                                }`}
                        >
                            {isWinningPost && <WinningHeaderArt />}
                            <div className="flex items-start justify-between gap-3">
                                <div className="min-w-0 flex-1">
                                    <span className="block text-[10px] font-semibold uppercase tracking-wide text-slate-400">
                                        {postHeaderLabel}
                                    </span>
                                    {!showComboLegs && (
                                        <>
                                            <div className="mt-3 h-px w-full bg-white/10" />
                                            <div className="mt-3 flex min-w-0 items-center justify-between gap-3">
                                                <div className="min-w-0 flex flex-1 items-center gap-2">
                                                    <span
                                                        className={`mt-2 h-1.5 w-1.5 rounded-full ${pickAccentDotTone}`}
                                                    />
                                                    <div className="min-w-0 flex-1">
                                                        {detailCategoryLabel && (
                                                            <span className="block text-[9px] font-semibold uppercase tracking-wide text-slate-400">
                                                                {detailCategoryLabel}
                                                            </span>
                                                        )}
                                                        <p
                                                            className={`mt-1 min-w-0 text-[12px] font-semibold leading-snug ${accent.text}`}
                                                            title={displayPick}
                                                        >
                                                            {pickLine}
                                                        </p>
                                                        {metaLabel && (
                                                            <p className="mt-1 truncate text-[10px] text-slate-400">
                                                                {metaLabel}
                                                            </p>
                                                        )}
                                                    </div>
                                                </div>
                                                <div className="flex flex-col items-end gap-1 pt-2">
                                                    <span className={`text-[11px] font-semibold ${accent.text}`}>
                                                        {oddsCopy}
                                                    </span>
                                                </div>
                                            </div>
                                        </>
                                    )}
                                </div>
                                {showComboLegs && (
                                    <div className="flex flex-col items-end">
                                        <span className="text-[12px] font-semibold text-slate-100">
                                            {oddsCopy}
                                        </span>
                                    </div>
                                )}
                            </div>
                            {showComboLegs && <div className="mt-3 h-px w-full bg-white/10" />}
                            {showComboLegs ? (
                                <>
                                    <ul className="mt-3 space-y-2">
                                        {pick.legs?.map((leg, index) => {
                                            const legPickLine = extractPickLine(leg.description);
                                            const legMatchup = extractMatchup(leg.description, leg.matchup) ?? leg?.matchup;
                                            const legTime = formatDateTime(leg.selection?.gameStartTime);
                                            const legMeta = [legMatchup, legTime !== PLACEHOLDER ? legTime : null]
                                                .filter(Boolean)
                                                .join(META_SEPARATOR);
                                            const legCategory = resolveLegCategoryLabel(leg.selection?.market);
                                            const legResult = leg.result ?? "pending";
                                            const legAccent = PICK_RESULT_ACCENTS[legResult] ?? PICK_RESULT_ACCENTS.pending;
                                            const legAccentDotTone = legResult === "win"
                                                ? "bg-emerald-300/80"
                                                : legResult === "loss"
                                                    ? "bg-rose-300/80"
                                                    : "bg-sky-300/80";
                                            return (
                                                <li
                                                    key={`${leg.description}-${index}`}
                                                    className="flex items-start justify-between gap-3"
                                                >
                                                    <div className="min-w-0 flex items-center gap-2">
                                                        <span
                                                            className={`mt-2 h-1.5 w-1.5 rounded-full ${legAccentDotTone}`}
                                                        />
                                                        <div className="min-w-0">
                                                            {legCategory && (
                                                                <span className="block text-[9px] font-semibold uppercase tracking-wide text-slate-400">
                                                                    {legCategory}
                                                                </span>
                                                            )}
                                                            <p className={`min-w-0 text-[12px] font-semibold leading-snug ${legAccent.text}`}>
                                                                {legPickLine}
                                                            </p>
                                                            {legMeta && (
                                                                <p className="mt-1 text-[10px] text-slate-400">{legMeta}</p>
                                                            )}
                                                        </div>
                                                    </div>
                                                    <div className="flex flex-col items-end gap-1 pt-2">
                                                        <span className={`text-[11px] font-semibold ${legAccent.text}`}>
                                                            {leg.odds_bracket ?? PLACEHOLDER}
                                                        </span>
                                                    </div>
                                                </li>
                                            );
                                        })}
                                    </ul>
                                </>
                            ) : null}
                        </div>
                    </div>

                    <div className="flex flex-wrap items-center justify-between gap-2">
                        <div className="flex flex-wrap items-center gap-2 text-[11px] uppercase tracking-wide text-[var(--text-secondary)]">
                            {!showComboLegs && comboLabel && (
                                <span className="rounded-full border border-white/10 bg-white/5 px-2 py-1 text-gray-200">
                                    {comboLabel}
                                </span>
                            )}
                        </div>
                        <div className="text-[11px] uppercase tracking-[0.18em] text-[var(--text-muted)]">
                            {sportLabel + " · " + postedLine}
                        </div>
                    </div>
                </div>
            )}
            {collapsed && (
                <div className="px-5 sm:px-6">
                    <div className="flex justify-end text-[11px] uppercase tracking-[0.18em] text-[var(--text-muted)]">
                        {sportLabel + " · " + postedLine}
                    </div>
                </div>
            )}
        </div>
    );
};

export default PostCard;
