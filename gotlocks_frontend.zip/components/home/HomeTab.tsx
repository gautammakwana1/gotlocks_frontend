"use client";

import { useCallback, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { useRouter } from "next/navigation";
import FeedList from "@/components/social/FeedList";
import { displayNameGradientStyle } from "@/lib/styles/text";
import { getLevelProgress } from "@/lib/utils/progression";
import { AppNotification, CurrentUser, Group, GroupObject, GroupSummary, PickReaction, RootState } from "@/lib/interfaces/interfaces";
import { useCurrentUser } from "@/lib/auth/useCurrentUser";
import { useSelector } from "react-redux";
import { useAppDispatch } from "@/lib/redux/hooks";
import { clearJoinedGroupByInviteCodeMessage, fetchMyGroupsRequest, joinedGroupByInviteCodeRequest } from "@/lib/redux/slices/groupsSlice";
import { clearFetchAllGlobalPostPicksMessage, createPickReactionRequest, fetchGlobalPendingTopHitPostsRequest } from "@/lib/redux/slices/pickSlice";
import { fetchMyTutorialProgressRequest, fetchProgressByUserIdRequest, updateTutorialProgressRequest } from "@/lib/redux/slices/progressSlice";
import { useToast } from "@/lib/state/ToastContext";
import { clearAllNotificationRequest, fetchNotificationListRequest, markNotificationReadRequest } from "@/lib/redux/slices/notificationSlice";
import NotificationsFeed from "./NotificationFeed";
import { getProfilePath } from "@/lib/utils/profileNavigation";
import ScrollUpButton from "../ui/ScrollUpButton";
import { MembersIcon, RightArrowIcon, SlipIcon, TrashIcon } from "../ui/SvgIcons";
import OnboardingModal from "../modals/OnboardingModal";
import { getLocalStorage } from "@/lib/utils/jwtUtils";
import { WELCOME_TUTORIAL } from "@/lib/onboarding/tutorials";
import Image from "next/image";
import HomeTabSkeleton from "../skeletons/home/HomeTabSkeleton";

type GroupSliceState = {
    group: {
        data?: {
            groups?: Array<Group>;
        };
        message?: string;
    } | null;
    loading: boolean;
    summary: GroupSummary[];
    joinLoading: boolean;
    error: string | null;
    message: string | null;
    hasMore: boolean;
    myGroups: GroupObject[] | null;
};

type GroupRootState = {
    group: GroupSliceState;
};

type ActionDefinition = {
    id: string;
    label: ReactNode;
    description: string;
    href: string;
    icon: ReactNode;
    featured?: boolean;
    onClick: () => void;
};

type ActivityTab = "posts" | "notifications";

type StatDefinition = {
    label: string;
    value: string;
    highlight?: boolean;
};

const TwoLineActionLabel = ({
    top,
    bottom,
}: {
    top: string;
    bottom: string;
}) => (
    <span className="flex flex-col leading-[1.1] lg:block lg:whitespace-nowrap">
        <span className="lg:inline">{top}</span>
        <span className="lg:hidden">{bottom}</span>
        <span className="hidden lg:inline"> {bottom}</span>
    </span>
);

// type TabIconProps = { className?: string };

const ActionCard = ({
    action,
    locked,
    onLockedTap,
}: {
    action: ActionDefinition;
    locked?: boolean;
    onLockedTap?: () => void;
}) => (
    <button
        type="button"
        onClick={locked ? onLockedTap : action.onClick}
        aria-label={locked ? "Locked — finish the league tour first" : undefined}
        className={`ui-accent-card group relative overflow-hidden rounded-[18px] border border-white/10 px-3 py-3 text-left shadow-sm transition sm:px-4 sm:py-4 lg:px-5 lg:py-5 ${locked ? "opacity-45" : ""
            }`}
    >
        <div
            aria-hidden
            className="pointer-events-none absolute -right-10 -top-10 h-24 w-24 rounded-full opacity-0 blur-3xl"
        />
        <div className="relative flex items-center justify-between gap-3">
            <p className="text-[11px] font-semibold text-white sm:text-sm">
                {action.label}
            </p>
            <div className="ui-accent-card-icon">
                {action.icon}
            </div>
        </div>
        {locked && (
            <span
                aria-hidden
                className="absolute right-1.5 top-1.5 flex h-4 w-4 items-center justify-center rounded-full bg-black/80 text-[9px] leading-none text-sky-200 ring-1 ring-sky-300/50"
            >
                <Image
                    src="/icons/lock.png"
                    alt="tutorial"
                    width={24}
                    height={24}
                    className="transition-transform p-[1px] duration-300 group-hover:scale-110"
                    draggable={false}
                />
            </span>
        )}
    </button>
);

const StatCard = ({ stat }: { stat: StatDefinition }) => (
    <div className="flex flex-col gap-1">
        <p className="text-[9px] uppercase tracking-[0.16em] text-gray-400 sm:text-[11px] sm:tracking-[0.2em]">
            {stat.label}
        </p>
        <p
            className={`text-lg font-semibold sm:text-2xl ${stat.highlight ? "text-blue-200" : "text-white"
                }`}
        >
            {stat.value}
        </p>
    </div>
);

const HomeTab = () => {
    const router = useRouter();
    const dispatch = useAppDispatch();
    const currentUser = useCurrentUser();
    const storedUser = getLocalStorage<CurrentUser>("currentUser");
    const { setToast } = useToast();
    const currentUserId = currentUser?.userId ?? undefined;
    const [joinCode, setJoinCode] = useState("");
    const [joinError, setJoinError] = useState<string | null>(null);
    const [joinOpen, setJoinOpen] = useState(false);
    const leagueCarouselRef = useRef<HTMLDivElement | null>(null);
    const slideDistanceRef = useRef(0);
    const resetTimeoutRef = useRef<number | null>(null);
    const resumeTimeoutRef = useRef<number | null>(null);
    const isCarouselPausedRef = useRef(false);
    const [activeLeagueIndex, setActiveLeagueIndex] = useState(0);
    const [notifications, setNotificaitons] = useState<AppNotification[]>([]);
    const [page, setPage] = useState(1);
    const [groupPage, setGroupPage] = useState(1);
    const [activityTab, setActivityTab] = useState<ActivityTab>("posts");
    const [showScrollTop, setShowScrollTop] = useState(false);
    const [showOnboarding, setShowOnboarding] = useState(false);
    const observer = useRef<IntersectionObserver | null>(null);
    const limit = 10;

    const { joinLoading, message, error, hasMore: myGroupsHasMore, myGroups, loading: groupLoading } = useSelector((state: GroupRootState) => state.group);
    const { postPicks, loading: pickLoader, message: pickMessage, hasMore } = useSelector((state: RootState) => state.pick);
    const { progress, picksCount, slipsCount, hasSeenIntro, loading: progressLoading } = useSelector((state: RootState) => state.progress);
    const { notification } = useSelector((state: RootState) => state.notifications);
    const { hasSeenWelcomeIntro, hasSeenGroupIntro } = useSelector((state: RootState) => state.progress);

    const actionsLocked = !hasSeenGroupIntro;
    const handleLockedActionTap = useCallback(() => {
        setToast({
            id: Date.now(),
            type: "info",
            message: "Tap the leagues tab to continue the tour 🔒",
            duration: 3000
        });
    }, [setToast]);

    const fetchData = useCallback((pageNum: number, customLimit?: number) => {
        const payload = { page: pageNum, limit: customLimit ?? limit };
        dispatch(fetchGlobalPendingTopHitPostsRequest(payload));
    }, [dispatch, limit]);

    useEffect(() => {
        if (!currentUserId) return;
        dispatch(fetchMyGroupsRequest({ page: 1, limit: 10 }));
        dispatch(fetchNotificationListRequest({}));
        fetchData(1);
        dispatch(fetchProgressByUserIdRequest({ user_id: currentUserId }));
        dispatch(fetchMyTutorialProgressRequest());
    }, [dispatch, currentUserId, fetchData]);

    useEffect(() => {
        if (pickLoader || !pickMessage) return;

        dispatch(clearFetchAllGlobalPostPicksMessage());
        fetchData(1, page * limit);
    }, [pickLoader, pickMessage, dispatch, page, limit, fetchData]);

    useEffect(() => {
        setShowOnboarding(!hasSeenIntro);
    }, [hasSeenIntro]);

    useEffect(() => {
        if (Array.isArray(notification)) {
            setNotificaitons(notification)
        };
    }, [notification]);

    useEffect(() => {
        const handleScroll = () => {
            if (window.scrollY > 400) {
                setShowScrollTop(true);
            } else {
                setShowScrollTop(false);
            }
        };

        window.addEventListener("scroll", handleScroll);
        return () => window.removeEventListener("scroll", handleScroll);
    }, []);

    const scrollToTop = () => {
        window.scrollTo({ top: 0, behavior: "smooth" });
    };

    const lastItemRef = useCallback((node: HTMLDivElement | null) => {
        if (pickLoader) return;
        if (observer.current) observer.current.disconnect();

        observer.current = new IntersectionObserver((entries) => {
            if (entries[0].isIntersecting && hasMore) {
                const nextPage = page + 1;
                setPage(nextPage);
                fetchData(nextPage);
            }
        });

        if (node) observer.current.observe(node);
    }, [pickLoader, hasMore, page, fetchData]);

    useEffect(() => {
        if (!joinLoading && message) {
            setToast({
                id: Date.now(),
                type: "success",
                message: message,
                duration: 3000,
            });
            setGroupPage(1);
            dispatch(fetchMyGroupsRequest({ page: 1, limit: 10 }));
        }
        if (!joinLoading && error) {
            setToast({
                id: Date.now(),
                type: "error",
                message: error,
                duration: 3000
            })
        }
        dispatch(clearJoinedGroupByInviteCodeMessage());
    }, [setToast, dispatch, joinLoading, message, error, router]);

    const handleLoadMoreGroups = useCallback(() => {
        if (groupLoading || !myGroupsHasMore) return;
        const nextGroupPage = groupPage + 1;
        setGroupPage(nextGroupPage);
        dispatch(fetchMyGroupsRequest({ page: nextGroupPage, limit: 10 }));
    }, [groupLoading, myGroupsHasMore, groupPage, dispatch]);

    const { level, xpIntoLevel, xpToNext } = getLevelProgress(
        progress?.lifetime_xp ?? 0
    );
    const xpLevelRatio = Math.min(1, xpIntoLevel / xpToNext);

    const winRate = picksCount?.win && picksCount?.total ? (picksCount.win / picksCount.total * 100) : 0;

    const sortedGroups = useMemo(() => {
        if (!Array.isArray(myGroups) || !myGroups.length) return [];

        const groups = myGroups;

        if (!currentUser?.userId) return groups;

        const commissionerGroups = groups.filter(
            (g: GroupObject) => g.created_by === currentUser.userId
        );
        const memberGroups = groups.filter(
            (g: GroupObject) => g.created_by !== currentUser.userId
        );

        return [...commissionerGroups, ...memberGroups];
    }, [myGroups, currentUser?.userId]);

    const orderedGroups = useMemo(
        () => [...sortedGroups].reverse(),
        [sortedGroups]
    );

    useEffect(() => {
        if (activeLeagueIndex >= orderedGroups.length - 2 && myGroupsHasMore && !groupLoading) {
            handleLoadMoreGroups();
        }
    }, [activeLeagueIndex, orderedGroups.length, myGroupsHasMore, groupLoading, handleLoadMoreGroups]);

    const carouselGroups = useMemo(
        () =>
            orderedGroups.length > 1
                ? [...orderedGroups, ...orderedGroups, ...orderedGroups]
                : orderedGroups,
        [orderedGroups]
    );

    const openJoinModal = useCallback(() => {
        setJoinOpen(true);
        setJoinError(null);
    }, []);

    const closeJoinModal = useCallback(() => {
        setJoinOpen(false);
        setJoinCode("");
        setJoinError(null);
    }, []);

    const handleJoin = (event: React.FormEvent<HTMLFormElement>) => {
        event.preventDefault();
        if (!currentUser) return;

        dispatch(joinedGroupByInviteCodeRequest({ invite_code: joinCode.trim() }));
        closeJoinModal();
    };

    const jumpCarouselToIndex = useCallback((targetIndex: number, distance?: number) => {
        const container = leagueCarouselRef.current;
        if (!container) return;
        const width = distance ?? slideDistanceRef.current ?? container.clientWidth;
        if (!width) return;
        container.style.scrollSnapType = "none";
        container.style.scrollBehavior = "auto";
        container.scrollTo({ left: targetIndex * width, behavior: "auto" });
        window.requestAnimationFrame(() => {
            container.style.scrollSnapType = "";
            container.style.scrollBehavior = "";
        });
    }, []);

    const scrollLeagueCarouselToIndex = useCallback(
        (index: number) => {
            const container = leagueCarouselRef.current;
            if (!container || orderedGroups.length === 0) return;
            const clampedIndex = Math.max(0, Math.min(index, orderedGroups.length - 1));
            const distance = slideDistanceRef.current || container.clientWidth;
            const targetIndex =
                orderedGroups.length > 1
                    ? orderedGroups.length + clampedIndex
                    : clampedIndex;
            container.scrollTo({ left: targetIndex * distance, behavior: "smooth" });
            setActiveLeagueIndex(clampedIndex);
        },
        [orderedGroups.length]
    );

    useEffect(() => {
        const container = leagueCarouselRef.current;
        if (!container || orderedGroups.length === 0) return;

        const alignToMiddle = () => {
            const children = Array.from(container.children) as HTMLElement[];
            const distance =
                children.length >= 2
                    ? children[1].offsetLeft - children[0].offsetLeft
                    : children[0]?.offsetWidth ?? container.clientWidth;
            slideDistanceRef.current = distance || container.clientWidth;
            if (orderedGroups.length > 1) {
                jumpCarouselToIndex(orderedGroups.length, slideDistanceRef.current);
                setActiveLeagueIndex(0);
            }
        };

        const rafId = window.requestAnimationFrame(alignToMiddle);
        return () => window.cancelAnimationFrame(rafId);
    }, [carouselGroups.length, orderedGroups.length, jumpCarouselToIndex]);

    useEffect(() => {
        const container = leagueCarouselRef.current;
        if (!container) return;

        const handleScroll = () => {
            const width = slideDistanceRef.current || container.clientWidth;
            if (!width || orderedGroups.length === 0) return;
            const rawIndexFloat = container.scrollLeft / width;
            const rawIndex = Math.round(rawIndexFloat);
            const total = orderedGroups.length;

            const normalizedIndex = ((rawIndex % total) + total) % total;
            setActiveLeagueIndex(normalizedIndex);

            if (resetTimeoutRef.current) {
                window.clearTimeout(resetTimeoutRef.current);
                resetTimeoutRef.current = null;
            }

            if (total > 1) {
                let resetTarget: number | null = null;
                if (rawIndexFloat < total - 0.1) {
                    resetTarget = rawIndex + total;
                } else if (rawIndexFloat >= total * 2 - 0.1) {
                    resetTarget = rawIndex - total;
                }

                if (resetTarget !== null) {
                    resetTimeoutRef.current = window.setTimeout(() => {
                        jumpCarouselToIndex(resetTarget as number, width);
                    }, 140);
                }
            }
        };

        handleScroll();
        container.addEventListener("scroll", handleScroll, { passive: true });
        return () => {
            if (resetTimeoutRef.current) {
                window.clearTimeout(resetTimeoutRef.current);
                resetTimeoutRef.current = null;
            }
            container.removeEventListener("scroll", handleScroll);
        };
    }, [orderedGroups.length, jumpCarouselToIndex]);

    useEffect(() => {
        const container = leagueCarouselRef.current;
        if (!container || orderedGroups.length <= 1) return;

        let intervalId: number | null = null;
        const media = window.matchMedia("(min-width: 640px)");

        const tick = () => {
            if (!leagueCarouselRef.current) return;
            const width = slideDistanceRef.current || leagueCarouselRef.current.clientWidth;
            if (!width) return;
            leagueCarouselRef.current.scrollBy({ left: width, behavior: "smooth" });
        };

        const start = () => {
            if (intervalId !== null) return;
            if (isCarouselPausedRef.current) return;
            intervalId = window.setInterval(tick, 5000);
        };

        const stop = () => {
            if (intervalId === null) return;
            window.clearInterval(intervalId);
            intervalId = null;
        };

        const scheduleResume = () => {
            if (resumeTimeoutRef.current) {
                window.clearTimeout(resumeTimeoutRef.current);
                resumeTimeoutRef.current = null;
            }
            resumeTimeoutRef.current = window.setTimeout(() => {
                isCarouselPausedRef.current = false;
                if (!media.matches) {
                    start();
                }
            }, 1200);
        };

        const pause = () => {
            isCarouselPausedRef.current = true;
            stop();
            if (resumeTimeoutRef.current) {
                window.clearTimeout(resumeTimeoutRef.current);
                resumeTimeoutRef.current = null;
            }
        };

        const handlePointerEnter = () => pause();
        const handlePointerLeave = () => scheduleResume();
        const handlePointerDown = () => pause();
        const handlePointerUp = () => scheduleResume();
        const handlePointerCancel = () => scheduleResume();
        const handleTouchStart = () => pause();
        const handleTouchEnd = () => scheduleResume();
        const handleTouchCancel = () => scheduleResume();

        const handleChange = (event: MediaQueryListEvent | MediaQueryList) => {
            if (event.matches) {
                stop();
            } else {
                start();
            }
        };

        handleChange(media);

        if (media.addEventListener) {
            media.addEventListener("change", handleChange);
        } else {
            media.addListener(handleChange);
        }

        container.addEventListener("pointerenter", handlePointerEnter);
        container.addEventListener("pointerleave", handlePointerLeave);
        container.addEventListener("pointerdown", handlePointerDown);
        container.addEventListener("pointerup", handlePointerUp);
        container.addEventListener("pointercancel", handlePointerCancel);
        container.addEventListener("touchstart", handleTouchStart, { passive: true });
        container.addEventListener("touchend", handleTouchEnd, { passive: true });
        container.addEventListener("touchcancel", handleTouchCancel, { passive: true });

        return () => {
            stop();
            if (resumeTimeoutRef.current) {
                window.clearTimeout(resumeTimeoutRef.current);
                resumeTimeoutRef.current = null;
            }
            if (media.removeEventListener) {
                media.removeEventListener("change", handleChange);
            } else {
                media.removeListener(handleChange);
            }
            container.removeEventListener("pointerenter", handlePointerEnter);
            container.removeEventListener("pointerleave", handlePointerLeave);
            container.removeEventListener("pointerdown", handlePointerDown);
            container.removeEventListener("pointerup", handlePointerUp);
            container.removeEventListener("pointercancel", handlePointerCancel);
            container.removeEventListener("touchstart", handleTouchStart);
            container.removeEventListener("touchend", handleTouchEnd);
            container.removeEventListener("touchcancel", handleTouchCancel);
        };
    }, [orderedGroups.length]);

    const maxVisibleDots = 5;
    const total = orderedGroups.length;

    let startIndex = 0;

    if (total > maxVisibleDots) {
        if (activeLeagueIndex <= 2) {
            startIndex = 0;
        } else if (activeLeagueIndex >= total - 3) {
            startIndex = total - maxVisibleDots;
        } else {
            startIndex = activeLeagueIndex - 2;
        }
    }

    const visibleDots = orderedGroups.slice(
        startIndex,
        startIndex + maxVisibleDots
    );

    const handleReaction = (pickId: string, reaction: PickReaction) => {
        if (reaction && pickId) {
            dispatch(createPickReactionRequest({ pick_id: pickId, action: reaction === "up" ? "liked" : "dislike" }));
        }
    };

    const handleViewProfile = useCallback(
        (userId: string) => {
            router.push(getProfilePath(userId, currentUserId));
        },
        [currentUserId, router]
    );

    const handleOpenGroup = useCallback(
        (groupId: string) => {
            router.push(`/league/${groupId}`);
        },
        [router]
    );

    const unreadNotifications = useMemo(
        () => notifications.filter((notification) => !notification.is_read).length,
        [notifications]
    );

    useEffect(() => {
        if (activityTab !== "notifications" || !currentUserId || unreadNotifications === 0) return;
        dispatch(markNotificationReadRequest({}));
    }, [activityTab, currentUserId, unreadNotifications, dispatch]);

    const handleClearAll = useCallback(() => {
        dispatch(clearAllNotificationRequest({}));
    }, [dispatch]);

    const handleCompleteWelcomeIntro = () => {
        // setShowOnboarding(false);
        // if (!hasSeenIntro) {
        //     dispatch(completeIntroRequest({}));
        // }
        dispatch(updateTutorialProgressRequest({ tutorial_key: "home" }));
    };

    const stats: StatDefinition[] = [
        {
            label: "Leagues",
            value: String(sortedGroups.length),
        },
        {
            label: "Active slips",
            value: String(slipsCount?.open_slip ?? 0),
        },
        {
            label: "Post wins",
            value: String(picksCount?.win ?? 0),
            highlight: true,
        },
        {
            label: "Post win rate",
            value: `${winRate.toFixed(1)}%`,
        },
    ];

    const quickActions: ActionDefinition[] = [
        {
            id: "create",
            label: <TwoLineActionLabel top="Start a" bottom="league" />,
            href: "/cag-explained",
            description: "Start a new league",
            featured: true,
            onClick: () => router.push("/cag-explained"),
            icon: (
                <MembersIcon className="h-3.5 w-3.5 overflow-visible sm:h-4 sm:w-4" />
            ),
        },
        {
            id: "join",
            label: <TwoLineActionLabel top="Join a" bottom="league" />,
            href: "/fantasy",
            description: "Join a league by invitation code",
            onClick: openJoinModal,
            icon: (
                <RightArrowIcon />
            ),
        },
        {
            id: "builder",
            label: <TwoLineActionLabel top="Build a" bottom="post" />,
            description: "Spin up a new post or slip pick.",
            href: "/pick-builder",
            onClick: () => router.push("/pick-builder"),
            icon: (
                <SlipIcon className="h-3.5 w-3.5 sm:h-4 sm:w-4" stroke="currentColor" fill="none" strokeWidth="1.5" aria-hidden={true} />
            ),
        },
    ];

    const isInitialLoading = groupLoading || progressLoading;

    if (isInitialLoading) {
        return <HomeTabSkeleton />;
    }

    return (
        <div className="flex flex-col gap-4 sm:gap-6">
            <section className="-mx-2 -mt-3 relative overflow-hidden rounded-[18px] border border-white/10 p-4 shadow-2xl shadow-black/40 animate-[homeFadeUp_0.7s_ease-out_both] sm:mx-0 sm:mt-0 sm:p-6 lg:p-8">
                <div
                    aria-hidden
                    className="pointer-events-none absolute inset-0 bg-gradient-to-br from-slate-950/90 via-black/84 to-blue-950/16"
                />
                <div
                    aria-hidden
                    className="pointer-events-none absolute inset-[1px] rounded-[17px] bg-gradient-to-b from-white/7 via-black/32 via-62% to-black/86"
                />
                <div
                    aria-hidden
                    className="pointer-events-none absolute inset-[1px] rounded-[17px] bg-[radial-gradient(circle_at_top,rgba(59,130,246,0.12),transparent_52%)]"
                />
                <div
                    aria-hidden
                    className="pointer-events-none absolute inset-[1px] rounded-[17px] bg-[linear-gradient(180deg,rgba(255,255,255,0.10),rgba(255,255,255,0.025)_16%,transparent_34%)]"
                />
                <div className="relative z-10 flex flex-col gap-5 sm:gap-6 lg:gap-8">
                    <div className="grid gap-3 sm:grid-cols-[minmax(0,0.9fr)_minmax(0,1.1fr)] sm:items-center sm:gap-4">
                        <div className="max-w-xl">
                            <h1 className="mt-2 text-2xl font-extrabold leading-tight text-white sm:mt-3 sm:text-3xl lg:text-4xl">
                                <span className="block">Welcome back,</span>
                                <span
                                    className="allow-caps block text-transparent bg-clip-text"
                                    style={displayNameGradientStyle}
                                >
                                    {storedUser?.username ?? "Member"}
                                </span>
                            </h1>
                        </div>
                        <div className="w-full lg:max-w-none lg:justify-self-start">
                            <div className="flex items-center justify-between text-[10px] uppercase tracking-[0.16em] text-gray-400 sm:text-xs sm:tracking-[0.2em]">
                                <span>Level {level}</span>
                                <span>
                                    {xpIntoLevel}/{xpToNext} XP
                                </span>
                            </div>
                            <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-white/10 sm:mt-3 sm:h-2">
                                <div
                                    className="h-full rounded-full bg-gradient-to-r from-sky-300 to-blue-500"
                                    style={{ width: `${Math.round(xpLevelRatio * 100)}%` }}
                                />
                            </div>
                        </div>
                    </div>
                    <div className="border-t border-white/10 pt-3 sm:pt-4">
                        <div className="grid w-full grid-cols-4 gap-2 sm:gap-6">
                            {stats.map((stat) => (
                                <StatCard key={stat.label} stat={stat} />
                            ))}
                        </div>
                    </div>
                    <div className="border-t border-white/10 pt-4 sm:pt-6">
                        <div className="mb-3 flex items-center justify-between gap-3 sm:mb-4">
                            <p className="text-[10px] uppercase tracking-[0.2em] text-gray-400 sm:text-xs sm:tracking-[0.24em]">
                                Your leagues
                            </p>
                            <button
                                type="button"
                                onClick={() => router.push("/fantasy")}
                                className="text-[9px] font-semibold tracking-[0.14em] text-gray-200 transition hover:text-white sm:text-[11px]"
                            >
                                manage
                            </button>
                        </div>
                        {sortedGroups.length === 0 ? (
                            <div className="rounded-[18px] border border-dashed border-white/20 bg-white/5 p-4 text-[11px] text-gray-300 sm:p-5 sm:text-sm">
                                You are not in any leagues yet. Start one to get the vibe going.
                            </div>
                        ) : (
                            <>
                                <div className="sm:hidden">
                                    <div
                                        ref={leagueCarouselRef}
                                        className="scrollbar-hide flex gap-3 overflow-x-auto scroll-smooth snap-x snap-mandatory"
                                    >
                                        {carouselGroups.map((group, index) => (
                                            <button
                                                key={`${group.id}-${index}`}
                                                type="button"
                                                onClick={() => router.push(`/league/${group.id}`)}
                                                className="relative min-h-[7.5rem] min-w-full snap-center rounded-[18px] border border-white/10 bg-gradient-to-br from-white/10 via-white/5 to-white/0 p-3 text-left shadow-lg shadow-black/30 transition hover:border-blue-400/60 hover:shadow-blue-500/25"
                                            >
                                                <span className="absolute right-3 top-3 text-[9px] uppercase tracking-[0.12em] text-gray-300">
                                                    code {group.invite_code}
                                                </span>
                                                <div className="flex h-full flex-col">
                                                    <h3
                                                        className="allow-caps pr-16 text-base font-extrabold text-transparent bg-clip-text"
                                                        style={displayNameGradientStyle}
                                                    >
                                                        {group.name}
                                                    </h3>
                                                    <p className="mt-1 text-[10px] text-gray-300 break-words line-clamp-2">
                                                        {group.description ??
                                                            "Run slips, share picks, and climb the table together."}
                                                    </p>
                                                    <span className="mt-auto pt-3 text-[9px] uppercase tracking-[0.16em] text-gray-400">
                                                        {group.member_count} members
                                                    </span>
                                                </div>
                                            </button>
                                        ))}
                                    </div>
                                    {orderedGroups.length > 1 && (
                                        <div className="mt-3 flex items-center justify-center gap-2">
                                            {visibleDots.map((group, index) => {
                                                const realIndex = startIndex + index;
                                                const isActive = realIndex === activeLeagueIndex;

                                                const distance = Math.abs(realIndex - activeLeagueIndex);

                                                return (
                                                    <button
                                                        key={group.id}
                                                        type="button"
                                                        onClick={() => scrollLeagueCarouselToIndex(realIndex)}
                                                        aria-label={`Go to league ${realIndex + 1}`}
                                                        className={`
                                                            rounded-full transition-all duration-300 ease-[cubic-bezier(0.4,0,0.2,1)]
                                                            ${isActive
                                                                ? "w-2 h-2 bg-white"
                                                                : distance === 1
                                                                    ? "w-1.5 h-1.5 bg-white/60"
                                                                    : "w-1 h-1 bg-white/30"
                                                            }
                                                        `}
                                                    />
                                                );
                                            })}
                                        </div>
                                    )}
                                </div>
                                <div className="hidden sm:grid sm:grid-cols-2 sm:gap-4">
                                    {orderedGroups.slice(0, 2).map((group) => (
                                        <button
                                            key={group.id}
                                            type="button"
                                            onClick={() => router.push(`/league/${group.id}`)}
                                            className="relative min-h-[9rem] rounded-[18px] border border-white/10 bg-gradient-to-br from-white/10 via-white/5 to-white/0 p-4 text-left shadow-lg shadow-black/30 transition hover:border-blue-400/60 hover:shadow-blue-500/25"
                                        >
                                            <span className="absolute right-4 top-4 text-[10px] uppercase tracking-[0.14em] text-gray-300">
                                                code {group.invite_code}
                                            </span>
                                            <div className="flex h-full flex-col">
                                                <h3
                                                    className="allow-caps pr-20 text-lg font-extrabold text-transparent bg-clip-text"
                                                    style={displayNameGradientStyle}
                                                >
                                                    {group.name}
                                                </h3>
                                                <p className="mt-1 text-xs text-gray-300 line-clamp-2">
                                                    {group.description ??
                                                        "Run slips, share picks, and climb the table together."}
                                                </p>
                                                <span className="mt-auto pt-4 text-[11px] uppercase tracking-[0.18em] text-gray-400">
                                                    {group.member_count} members
                                                </span>
                                            </div>
                                        </button>
                                    ))}
                                </div>
                            </>
                        )}
                    </div>
                </div>
            </section>

            <section
                className="-mx-2 grid grid-cols-3 gap-2 animate-[homeFadeUp_0.7s_ease-out_both] sm:mx-0 sm:gap-4"
                style={{ animationDelay: "0.1s" }}
            >
                {quickActions.map((action) => (
                    <ActionCard
                        key={action.id}
                        action={action}
                        locked={actionsLocked}
                        onLockedTap={handleLockedActionTap}
                    />
                ))}
            </section>

            <section
                className="animate-[homeFadeUp_0.7s_ease-out_both]"
                style={{ animationDelay: "0.15s" }}
            >
                <div className="space-y-4">
                    <div className="-mx-5 sm:mx-0">
                        <div className="h-px w-full bg-white/10" />
                        <div className="px-5 sm:px-0">
                            <div className="mt-2 flex items-center justify-between gap-5">
                                <div className="flex items-center gap-5">
                                    <button
                                        type="button"
                                        onClick={() => setActivityTab("posts")}
                                        className={`text-[11px] tracking-[0.24em] transition ${activityTab === "posts"
                                            ? "text-white"
                                            : "text-gray-400 hover:text-white"
                                            }`}
                                    >
                                        recent posts
                                    </button>
                                    <button
                                        type="button"
                                        onClick={() => setActivityTab("notifications")}
                                        className={`inline-flex items-center gap-2 text-[11px] tracking-[0.24em] transition ${activityTab === "notifications"
                                            ? "text-white"
                                            : "text-gray-400 hover:text-white"
                                            }`}
                                    >
                                        <span>notifications</span>
                                        {unreadNotifications > 0 ? (
                                            <span className="rounded-full border border-blue-300/40 bg-blue-500/15 px-1.5 py-0.5 text-[9px] tracking-normal text-blue-100">
                                                {unreadNotifications}
                                            </span>
                                        ) : null}
                                    </button>
                                </div>
                                {activityTab === "notifications" && notifications.length > 0 && (
                                    <button
                                        type="button"
                                        onClick={handleClearAll}
                                        className="inline-flex items-center gap-1.5 rounded-lg border border-white/10 bg-white/5 px-2.5 py-1 text-[9px] uppercase tracking-[0.16em] text-gray-400 transition hover:border-white/20 hover:bg-white/10 hover:text-white sm:text-[10px] sm:tracking-[0.18em]"
                                    >
                                        <TrashIcon className={`h-3 w-3 shrink-0`} />
                                        <span>clear all</span>
                                    </button>
                                )}
                            </div>
                        </div>
                    </div>

                    {activityTab === "posts" ? (
                        <FeedList
                            items={postPicks}
                            currentUserId={currentUserId}
                            onReaction={handleReaction}
                            onViewProfile={handleViewProfile}
                            showReactions={true}
                            showTopBorder={true}
                            loading={pickLoader}
                            lastItemRef={lastItemRef}
                            emptyCopy="There are no pending public posts at the moment."
                        />
                    ) : (
                        <NotificationsFeed
                            onOpenProfile={handleViewProfile}
                            onOpenGroup={handleOpenGroup}
                        />
                    )}
                </div>
            </section>
            <OnboardingModal
                open={!hasSeenWelcomeIntro}
                steps={WELCOME_TUTORIAL}
                onClose={handleCompleteWelcomeIntro}
                finalCtaLabel="finish"
            />
            {joinOpen && (
                <ModalShell onClose={closeJoinModal} maxWidthClass="max-w-sm">
                    <form onSubmit={handleJoin} className="space-y-4 text-center">
                        <div className="space-y-1">
                            <p className="text-xs uppercase tracking-[0.16em] text-gray-400">
                                join a league
                            </p>
                            <p className="text-lg font-semibold text-white">Enter invite code</p>
                        </div>
                        <input
                            type="text"
                            value={joinCode}
                            onChange={(event) => {
                                let value = event.target.value;
                                value = value.replace(/\D/g, "").slice(0, 5);
                                setJoinCode(value);
                                setJoinError(null);
                            }}
                            maxLength={5}
                            inputMode="numeric"
                            placeholder="invite code"
                            autoFocus
                            className="ui-input-accent w-full rounded-2xl border border-white/15 bg-black/60 px-4 py-2.5 text-base sm:text-sm text-white outline-none transition"
                        />
                        {joinError && <p className="text-xs font-semibold text-red-200">{joinError}</p>}
                        <div className="flex justify-center gap-3">
                            <button
                                type="button"
                                onClick={closeJoinModal}
                                className="rounded-xl border border-white/15 px-4 py-2 text-sm font-semibold uppercase tracking-wide text-gray-200 transition hover:border-white/30 hover:text-white"
                            >
                                Cancel
                            </button>
                            <button
                                type="submit"
                                className="ui-accent-button rounded-xl px-4 py-2 text-sm font-semibold uppercase tracking-wide transition disabled:cursor-not-allowed"
                                disabled={!joinCode || joinCode.length !== 5}
                            >
                                Join
                            </button>
                        </div>
                    </form>
                </ModalShell>
            )}

            {showScrollTop && (
                <ScrollUpButton scrollToTop={scrollToTop} />
            )}
        </div>
    );
};

export default HomeTab;

const ModalShell = ({
    children,
    onClose,
    maxWidthClass = "max-w-3xl",
}: {
    children: ReactNode;
    onClose: () => void;
    maxWidthClass?: string;
}) => (
    <div
        className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 px-4 backdrop-blur-sm"
        onClick={onClose}
    >
        <div
            className={`relative w-full ${maxWidthClass} max-h-[90vh] overflow-y-auto rounded-3xl border border-white/10 bg-black p-5 shadow-2xl`}
            onClick={(event) => event.stopPropagation()}
        >
            {children}
        </div>
    </div>
);
